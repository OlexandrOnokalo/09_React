const Header = () => {
    return (
        <div className="header">
            <h3>React lesson 2</h3>
        </div>
    );
};

export default Header;